document.addEventListener('DOMContentLoaded', () => {
    // Base URL for Flask API
    const API_BASE_URL = 'http://localhost:5000';

    // Store Chart.js instances to manage canvas reuse
    let revenueChartInstance = null;
    let productsChartInstance = null;

    // Function to fetch with retry
    async function fetchWithRetry(url, options, retries = 3, delay = 1000) {
        for (let i = 0; i < retries; i++) {
            try {
                const response = await fetch(url, options);
                if (response.status === 401 || response.status === 403) {
                    // Redirect to login page on unauthorized or forbidden
                    console.log(`Received ${response.status} - Redirecting to login`);
                    window.location.href = `${API_BASE_URL}/api/login`;
                    throw new Error(`Unauthorized or Forbidden - redirecting to login (Status: ${response.status})`);
                }
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return await response.json();
            } catch (error) {
                if (i === retries - 1) throw error;
                console.warn(`Fetch failed, retrying (${i + 1}/${retries})...`, error);
                await new Promise(resolve => setTimeout(resolve, delay));
            }
        }
    }

    // Function to fetch and update dashboard data
    function loadDashboardData() {
        // Log session details for debugging
        console.log('Session Details Before Fetch:', {
            cookies: document.cookie,
            sessionID: 'default'
        });

        fetchWithRetry(`${API_BASE_URL}/api/admin_dashboard_data`, {
            headers: { 'Session-ID': 'default' },
            credentials: 'include'
        })
            .then(data => {
                // Update dashboard cards
                document.getElementById('total-invoices').textContent = data.totalInvoices;
                document.getElementById('total-revenue').textContent = `₹${data.totalRevenue.toLocaleString('en-IN')}`;
                document.getElementById('active-users').textContent = data.activeUsers;
                document.getElementById('products-sold').textContent = data.productsSold;

                // Destroy existing chart instances if they exist
                if (revenueChartInstance) {
                    revenueChartInstance.destroy();
                    revenueChartInstance = null;
                }
                if (productsChartInstance) {
                    productsChartInstance.destroy();
                    productsChartInstance = null;
                }

                // Log charts-grid styles before rendering charts
                const chartsGrid = document.querySelector('.charts-grid');
                const chartsGridStyles = window.getComputedStyle(chartsGrid);
                console.log('Charts Grid Styles Before Rendering:', {
                    display: chartsGridStyles.display,
                    gridTemplateColumns: chartsGridStyles.gridTemplateColumns,
                    width: chartsGridStyles.width,
                    height: chartsGridStyles.height
                });

                // Revenue Chart
                try {
                    const revenueCanvas = document.getElementById('revenueChart');
                    const revenueCtx = revenueCanvas.getContext('2d');
                    revenueChartInstance = new Chart(revenueCtx, {
                        type: 'line',
                        data: {
                            labels: data.labels,
                            datasets: [{
                                label: 'Revenue (₹)',
                                data: data.revenueData,
                                borderColor: '#3498db',
                                backgroundColor: 'rgba(52, 152, 219, 0.2)',
                                fill: true,
                                tension: 0.4
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: {
                                y: { beginAtZero: true }
                            },
                            animation: {
                                duration: 1000,
                                easing: 'easeOutQuart'
                            }
                        }
                    });

                    // Log canvas dimensions
                    console.log('Revenue Chart Canvas Dimensions:', {
                        width: revenueCanvas.width,
                        height: revenueCanvas.height,
                        clientWidth: revenueCanvas.clientWidth,
                        clientHeight: revenueCanvas.clientHeight
                    });
                } catch (chartError) {
                    console.error('Error creating revenue chart:', chartError);
                }

                // Top Products Chart
                try {
                    const productsCanvas = document.getElementById('productsChart');
                    const productsCtx = productsCanvas.getContext('2d');
                    productsChartInstance = new Chart(productsCtx, {
                        type: 'bar',
                        data: {
                            labels: data.productData.map(p => p.name),
                            datasets: [{
                                label: 'Units Sold',
                                data: data.productData.map(p => p.sold),
                                backgroundColor: ['#3498db', '#e74c3c', '#2ecc71', '#f1c40f', '#9b59b6']
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: {
                                y: { beginAtZero: true }
                            },
                            animation: {
                                duration: 1000,
                                easing: 'easeOutQuart'
                            }
                        }
                    });

                    // Log canvas dimensions
                    console.log('Products Chart Canvas Dimensions:', {
                        width: productsCanvas.width,
                        height: productsCanvas.height,
                        clientWidth: productsCanvas.clientWidth,
                        clientHeight: productsCanvas.clientHeight
                    });
                } catch (chartError) {
                    console.error('Error creating products chart:', chartError);
                }

                // Resize charts after DOM is fully updated
                const resizeCharts = () => {
                    if (revenueChartInstance) {
                        revenueChartInstance.resize();
                        console.log('Revenue Chart Resized');
                    }
                    if (productsChartInstance) {
                        productsChartInstance.resize();
                        console.log('Products Chart Resized');
                    }

                    // Log charts-grid styles after resizing
                    console.log('Charts Grid Styles After Resizing:', {
                        display: chartsGridStyles.display,
                        gridTemplateColumns: chartsGridStyles.gridTemplateColumns,
                        width: chartsGridStyles.width,
                        height: chartsGridStyles.height
                    });
                };

                // Use requestAnimationFrame with a longer delay
                requestAnimationFrame(() => {
                    setTimeout(resizeCharts, 300);
                });

                // Recent Invoices Table
                const invoicesTable = document.getElementById('invoices-table');
                invoicesTable.innerHTML = ''; // Clear existing data
                if (data.recentInvoices && data.recentInvoices.length > 0) {
                    data.recentInvoices.forEach(invoice => {
                        const row = document.createElement('tr');
                        row.innerHTML = `
                            <td>${invoice.id}</td>
                            <td>${invoice.client}</td>
                            <td>₹${invoice.amount.toLocaleString('en-IN')}</td>
                            <td>${invoice.date}</td>
                        `;
                        invoicesTable.appendChild(row);
                    });
                } else {
                    invoicesTable.innerHTML = '<tr><td colspan="4">No recent invoices available</td></tr>';
                }
            })
            .catch(error => {
                console.error('Error fetching dashboard data:', error);
                const invoicesTable = document.getElementById('invoices-table');
                invoicesTable.innerHTML = '<tr><td colspan="4">Error loading dashboard data: ' + error.message + '</td></tr>';
            });
    }

    // Check authentication status before loading dashboard
    function checkAuthStatus() {
        fetchWithRetry(`${API_BASE_URL}/api/status`, {
            credentials: 'include'
        })
            .then(data => {
                console.log('Auth Status:', data);
                if (!data.user_authenticated || data.user_role !== 'admin') {
                    console.log('User not authenticated or not admin, redirecting to login');
                    window.location.href = `${API_BASE_URL}/api/login`;
                } else {
                    loadDashboardData(); // Proceed to load dashboard data
                }
            })
            .catch(error => {
                console.error('Error checking auth status:', error);
                window.location.href = `${API_BASE_URL}/api/login`;
            });
    }

    // Load dashboard data on page load after checking auth
    checkAuthStatus();

    // Handle sidebar link clicks
    const dashboardLink = document.querySelector('.sidebar a[href="#"].active');
    const productsLink = document.getElementById('products-link');
    const clientsLink = document.getElementById('clients-link');
    const logoutLink = document.getElementById('logout-link');

    const dashboardSection = document.querySelectorAll('.charts-grid, .recent-invoices');
    const productsSection = document.getElementById('products-section');
    const clientsSection = document.getElementById('clients-section');

    // Function to toggle sections using visibility
    function showSection(sectionToShow, sectionsToHide, activeLink) {
        sectionsToHide.forEach(section => {
            section.style.visibility = 'hidden';
            section.style.position = 'absolute';
            section.style.width = '0';
            section.style.height = '0';
        });
        sectionToShow.style.visibility = 'visible';
        sectionToShow.style.position = 'static';
        sectionToShow.style.width = 'auto';
        sectionToShow.style.height = 'auto';
        document.querySelectorAll('.sidebar a').forEach(link => link.classList.remove('active'));
        activeLink.classList.add('active');

        // Log the section being shown for debugging
        const sectionStyles = window.getComputedStyle(sectionToShow);
        console.log(`Showing Section: ${sectionToShow.id || sectionToShow.className}`, {
            visibility: sectionStyles.visibility,
            position: sectionStyles.position,
            width: sectionStyles.width,
            height: sectionStyles.height
        });
    }

    // Dashboard (default view)
    dashboardLink.addEventListener('click', (e) => {
        e.preventDefault();
        showSection(dashboardSection[0].parentNode, [productsSection, clientsSection], dashboardLink);
        dashboardSection.forEach(section => {
            section.style.visibility = 'visible';
            section.style.position = 'static';
            section.style.width = 'auto';
            section.style.height = 'auto';
        });
        checkAuthStatus(); // Check auth before reloading data
    });

    // Products link
    productsLink.addEventListener('click', (e) => {
        e.preventDefault();
        showSection(productsSection, [clientsSection, ...dashboardSection], productsLink);

        // Fetch products data
        fetchWithRetry(`${API_BASE_URL}/api/get_products`, {
            headers: { 'Session-ID': 'default' },
            credentials: 'include'
        })
            .then(data => {
                const productsTable = document.getElementById('products-table');
                productsTable.innerHTML = ''; // Clear existing data
                if (data.products && data.products.length > 0) {
                    data.products.forEach(product => {
                        const row = document.createElement('tr');
                        row.innerHTML = `
                            <td>${product.name}</td>
                            <td>₹${product.price.toLocaleString('en-IN')}</td>
                            <td>${product.gst_rate || 18}%</td>
                        `;
                        productsTable.appendChild(row);
                    });
                } else {
                    productsTable.innerHTML = '<tr><td colspan="3">No products available</td></tr>';
                }
            })
            .catch(error => {
                console.error('Error fetching products:', error);
                document.getElementById('products-table').innerHTML = '<tr><td colspan="3">Error loading products: ' + error.message + '</td></tr>';
            });
    });

    // Clients link
    clientsLink.addEventListener('click', (e) => {
        e.preventDefault();
        showSection(clientsSection, [productsSection, ...dashboardSection], clientsLink);

        // Fetch clients data
        fetchWithRetry(`${API_BASE_URL}/api/client/get`, {
            headers: { 'Session-ID': 'default' },
            credentials: 'include'
        })
            .then(data => {
                const clientsTable = document.getElementById('clients-table');
                clientsTable.innerHTML = ''; // Clear existing data
                const client = data.client || {};
                if (client.name || client.address || client.gst_number || client.phone || client.email) {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${client.name || 'N/A'}</td>
                        <td>${client.address || 'N/A'}</td>
                        <td>${client.gst_number || 'N/A'}</td>
                        <td>${client.phone || 'N/A'}</td>
                        <td>${client.email || 'N/A'}</td>
                    `;
                    clientsTable.appendChild(row);
                } else {
                    clientsTable.innerHTML = '<tr><td colspan="5">No client data available</td></tr>';
                }
            })
            .catch(error => {
                console.error('Error fetching clients:', error);
                document.getElementById('clients-table').innerHTML = '<tr><td colspan="5">Error loading clients: ' + error.message + '</td></tr>';
            });
    });

    // Logout link
    logoutLink.addEventListener('click', (e) => {
        e.preventDefault();
        fetchWithRetry(`${API_BASE_URL}/api/logout`, {
            method: 'GET',
            credentials: 'include'
        })
            .then(() => {
                window.location.href = `${API_BASE_URL}/api/login`;
            })
            .catch(error => {
                console.error('Error logging out:', error);
                alert('Error logging out: ' + error.message);
            });
    });
});