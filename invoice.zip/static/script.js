// AI Invoice Assistant - ChatGPT Style JavaScript

class InvoiceAssistant {
    constructor() {
        this.API_BASE_URL = '/api';
        this.sessionId = this.generateSessionId();
        this.isProcessing = false;
        this.isConnected = false;
        this.currentTheme = localStorage.getItem('theme') || 'light';
        this.chatHistory = JSON.parse(localStorage.getItem('chatHistory')) || [];
        this.currentChatId = null;
        
        // DOM elements cache
        this.elements = {};
        
        this.init();
    }

    generateSessionId() {
        return 'session_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now();
    }

    init() {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.setup());
        } else {
            this.setup();
        }
    }

    setup() {
        this.cacheElements();
        this.setupEventListeners();
        this.setupDragAndDrop();
        this.initTheme();
        this.checkConnection();
        this.loadClientDetails();
        this.setupAutoResize();
        
        // Focus input
        setTimeout(() => {
            if (this.elements.messageInput) {
                this.elements.messageInput.focus();
            }
        }, 100);

        console.log('🚀 AI Invoice Assistant initialized');
        console.log('📱 Session ID:', this.sessionId);
    }

    cacheElements() {
        // Cache all important DOM elements
        const elementIds = [
            'sidebar', 'sidebarToggle', 'mobileOverlay', 'newChatBtn',
            'chatList', 'sidebarProductCount', 'sidebarCartCount',
            'connectionStatus', 'statusDot', 'statusText', 'headerCartCount',
            'downloadChatBtn', 'themeIcon', 'chatMessages', 'typingIndicator',
            'messageInput', 'sendBtn', 'sendIcon', 'loadingSpinner',
            'uploadModal', 'clientModal', 'uploadArea', 'fileInput',
            'uploadProgress', 'progressFill', 'fileName', 'uploadPercent',
            'clientForm', 'clientName', 'clientEmail', 'clientPhone',
            'clientAddress', 'clientGST', 'clientPlace'
        ];

        elementIds.forEach(id => {
            this.elements[id] = document.getElementById(id);
        });
    }

    setupEventListeners() {
        // Sidebar toggle
        if (this.elements.sidebarToggle) {
            this.elements.sidebarToggle.addEventListener('click', () => this.toggleSidebar());
        }

        // Mobile overlay
        if (this.elements.mobileOverlay) {
            this.elements.mobileOverlay.addEventListener('click', () => this.closeSidebar());
        }

        // New chat button
        if (this.elements.newChatBtn) {
            this.elements.newChatBtn.addEventListener('click', () => this.startNewChat());
        }

        // Send message
        if (this.elements.sendBtn) {
            this.elements.sendBtn.addEventListener('click', () => this.sendMessage());
        }

        // Message input
        if (this.elements.messageInput) {
            this.elements.messageInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.sendMessage();
                }
            });
        }

        // File upload
        if (this.elements.fileInput) {
            this.elements.fileInput.addEventListener('change', (e) => this.handleFileUpload(e));
        }

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => this.handleKeyboardShortcuts(e));

        // Window resize
        window.addEventListener('resize', () => this.handleResize());
    }

    setupDragAndDrop() {
        if (!this.elements.uploadArea) return;

        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            this.elements.uploadArea.addEventListener(eventName, this.preventDefaults, false);
        });

        ['dragenter', 'dragover'].forEach(eventName => {
            this.elements.uploadArea.addEventListener(eventName, () => {
                this.elements.uploadArea.classList.add('dragover');
            }, false);
        });

        ['dragleave', 'drop'].forEach(eventName => {
            this.elements.uploadArea.addEventListener(eventName, () => {
                this.elements.uploadArea.classList.remove('dragover');
            }, false);
        });

        this.elements.uploadArea.addEventListener('drop', (e) => {
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                this.elements.fileInput.files = files;
                this.handleFileUpload({ target: this.elements.fileInput });
            }
        }, false);

        this.elements.uploadArea.addEventListener('click', () => {
            this.elements.fileInput.click();
        });
    }

    preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    setupAutoResize() {
        if (this.elements.messageInput) {
            this.elements.messageInput.addEventListener('input', () => {
                this.elements.messageInput.style.height = 'auto';
                this.elements.messageInput.style.height = Math.min(this.elements.messageInput.scrollHeight, 120) + 'px';
            });
        }
    }

    initTheme() {
        document.documentElement.setAttribute('data-theme', this.currentTheme);
        this.updateThemeIcon();
    }

    updateThemeIcon() {
        if (this.elements.themeIcon) {
            this.elements.themeIcon.className = this.currentTheme === 'dark' ? 'fas fa-moon' : 'fas fa-sun';
        }
    }

    toggleTheme() {
        this.currentTheme = this.currentTheme === 'light' ? 'dark' : 'light';
        document.documentElement.setAttribute('data-theme', this.currentTheme);
        localStorage.setItem('theme', this.currentTheme);
        this.updateThemeIcon();
    }

    toggleSidebar() {
        if (window.innerWidth <= 768) {
            this.elements.sidebar.classList.add('open');
            this.elements.mobileOverlay.classList.add('active');
        }
    }

    closeSidebar() {
        this.elements.sidebar.classList.remove('open');
        this.elements.mobileOverlay.classList.remove('active');
    }

    async checkConnection() {
        try {
            const response = await fetch(`${this.API_BASE_URL}/status`);
            this.setConnectionStatus(response.ok);
            
            if (response.ok) {
                await this.loadProductStats();
            }
        } catch (error) {
            console.error('Connection error:', error);
            this.setConnectionStatus(false);
        }
    }

    setConnectionStatus(connected) {
        this.isConnected = connected;
        
        if (this.elements.statusDot) {
            this.elements.statusDot.className = `status-dot ${connected ? '' : 'offline'}`;
        }
        
        if (this.elements.statusText) {
            this.elements.statusText.textContent = connected ? 'Connected' : 'Offline';
        }
    }

    async loadProductStats() {
        try {
            const response = await fetch(`${this.API_BASE_URL}/get_products`, {
                headers: { 'Session-ID': this.sessionId }
            });
            
            if (response.ok) {
                const data = await response.json();
                this.updateProductCount(data.count);
            }
        } catch (error) {
            console.error('Error loading product stats:', error);
        }
    }

    updateProductCount(count) {
        if (this.elements.sidebarProductCount) {
            this.elements.sidebarProductCount.textContent = count;
        }
    }

    updateCartCount(count) {
        if (this.elements.sidebarCartCount) {
            this.elements.sidebarCartCount.textContent = count;
        }
        if (this.elements.headerCartCount) {
            this.elements.headerCartCount.textContent = count;
        }
    }

    startNewChat() {
        this.currentChatId = this.generateSessionId();
        this.sessionId = this.currentChatId;
        
        // Clear chat messages
        if (this.elements.chatMessages) {
            this.elements.chatMessages.innerHTML = this.getWelcomeMessage();
        }
        
        // Update chat history UI
        this.updateChatList();
        
        this.closeSidebar();
    }

    getWelcomeMessage() {
        return `
            <div class="message-group">
                <div class="message ai-message">
                    <div class="message-avatar">
                        <i class="fas fa-robot"></i>
                    </div>
                    <div class="message-content">
                        <div class="message-text">
                            <h3>Welcome to AI Invoice Assistant! 👋</h3>
                            <p>I'm here to help you manage products, create smart carts, and generate professional invoices. Here's what I can do:</p>
                            <ul class="feature-list">
                                <li><strong>Product Management:</strong> Add, remove, and search products</li>
                                <li><strong>Smart Cart:</strong> Apply discounts and manage quantities</li>
                                <li><strong>Invoice Generation:</strong> Create professional PDF invoices</li>
                                <li><strong>Client Management:</strong> Store and manage customer details</li>
                            </ul>
                            <p class="help-text">Try saying: <code>"add 5 laptops with 10% discount"</code> or <code>"show my cart"</code></p>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    async sendMessage() {
        if (!this.elements.messageInput) return;
        
        const message = this.elements.messageInput.value.trim();
        if (!message || this.isProcessing || !this.isConnected) return;

        // Add user message
        this.addMessage(message, 'user');
        this.elements.messageInput.value = '';
        this.elements.messageInput.style.height = 'auto';

        this.setProcessing(true);
        this.showTyping();

        try {
            const response = await fetch(`${this.API_BASE_URL}/chat`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Session-ID': this.sessionId
                },
                body: JSON.stringify({
                    message: message,
                    session_id: this.sessionId
                })
            });

            if (response.ok) {
                const data = await response.json();
                
                // Update cart count if provided
                if (data.cart_count !== undefined) {
                    this.updateCartCount(data.cart_count);
                }
                
                // Handle special actions
                if (data.action_data && data.action_data.action === 'generate_invoice') {
                    await this.generateInvoiceFromCart();
                } else {
                    this.addMessage(data.response, 'ai');
                }
            } else {
                const errorText = await response.text();
                this.addMessage(`❌ Error: ${errorText}`, 'ai', true);
            }
        } catch (error) {
            console.error('Send message error:', error);
            this.addMessage('❌ Connection error. Please try again.', 'ai', true);
        } finally {
            this.hideTyping();
            this.setProcessing(false);
        }
    }

    addMessage(content, type = 'ai', isError = false) {
        if (!this.elements.chatMessages) return;

        const messageGroup = document.createElement('div');
        messageGroup.className = 'message-group';

        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${type}-message`;

        const avatarDiv = document.createElement('div');
        avatarDiv.className = 'message-avatar';
        avatarDiv.innerHTML = type === 'user' ? '<i class="fas fa-user"></i>' : '<i class="fas fa-robot"></i>';

        const contentDiv = document.createElement('div');
        contentDiv.className = 'message-content';

        const textDiv = document.createElement('div');
        textDiv.className = 'message-text';
        
        if (isError) {
            textDiv.style.color = 'var(--danger)';
        }
        
        // Handle HTML content vs plain text
        if (content.includes('<')) {
            textDiv.innerHTML = content;
        } else {
            textDiv.textContent = content;
        }

        contentDiv.appendChild(textDiv);
        messageDiv.appendChild(avatarDiv);
        messageDiv.appendChild(contentDiv);
        messageGroup.appendChild(messageDiv);

        this.elements.chatMessages.appendChild(messageGroup);
        this.scrollToBottom();
    }

    showTyping() {
        if (this.elements.typingIndicator) {
            this.elements.typingIndicator.style.display = 'flex';
            this.scrollToBottom();
        }
    }

    hideTyping() {
        if (this.elements.typingIndicator) {
            this.elements.typingIndicator.style.display = 'none';
        }
    }

    setProcessing(processing) {
        this.isProcessing = processing;
        
        if (this.elements.sendBtn) {
            this.elements.sendBtn.disabled = processing;
        }
        
        if (processing) {
            this.elements.loadingSpinner.style.display = 'block';
            this.elements.sendIcon.style.display = 'none';
        } else {
            this.elements.loadingSpinner.style.display = 'none';
            this.elements.sendIcon.style.display = 'block';
        }
    }

    scrollToBottom() {
        if (this.elements.chatMessages) {
            this.elements.chatMessages.scrollTop = this.elements.chatMessages.scrollHeight;
        }
    }

    async handleFileUpload(event) {
        const file = event.target.files[0];
        if (!file) return;

        // Validate file type
        const allowedTypes = ['.csv', '.xlsx', '.xls'];
        const fileExtension = '.' + file.name.split('.').pop().toLowerCase();
        if (!allowedTypes.includes(fileExtension)) {
            this.addMessage('❌ Please upload only CSV or Excel files', 'ai', true);
            return;
        }

        this.showUploadProgress(file.name);

        const formData = new FormData();
        formData.append('file', file);

        try {
            const response = await fetch(`${this.API_BASE_URL}/upload_catalog`, {
                method: 'POST',
                headers: { 'Session-ID': this.sessionId },
                body: formData
            });

            if (response.ok) {
                const data = await response.json();
                if (data.success) {
                    this.updateProductCount(data.product_count);
                    this.addMessage(`✅ Successfully uploaded ${data.product_count} products from ${data.filename}`, 'ai');
                    this.closeUploadModal();
                } else {
                    this.addMessage(`❌ ${data.error || 'Upload failed'}`, 'ai', true);
                }
            } else {
                this.addMessage('❌ Upload failed', 'ai', true);
            }
        } catch (error) {
            console.error('Upload error:', error);
            this.addMessage('❌ Network error during upload', 'ai', true);
        } finally {
            this.hideUploadProgress();
        }
    }

    showUploadProgress(fileName) {
        if (this.elements.fileName) {
            this.elements.fileName.textContent = fileName;
        }
        
        if (this.elements.uploadProgress) {
            this.elements.uploadProgress.style.display = 'block';
        }

        // Simulate progress
        let progress = 0;
        const interval = setInterval(() => {
            progress += 10;
            if (this.elements.progressFill) {
                this.elements.progressFill.style.width = progress + '%';
            }
            if (this.elements.uploadPercent) {
                this.elements.uploadPercent.textContent = progress + '%';
            }
            if (progress >= 100) {
                clearInterval(interval);
            }
        }, 100);
    }

    hideUploadProgress() {
        setTimeout(() => {
            if (this.elements.uploadProgress) {
                this.elements.uploadProgress.style.display = 'none';
            }
        }, 1000);
    }

    async generateInvoiceFromCart() {
        try {
            this.addMessage('🔄 Generating PDF invoice from cart...', 'ai');
            
            const response = await fetch(`${this.API_BASE_URL}/generate_invoice_from_cart`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Session-ID': this.sessionId
                },
                body: JSON.stringify({ session_id: this.sessionId })
            });

            if (response.ok) {
                const data = await response.json();
                if (data.success) {
                    const downloadBtn = `<a href="#" class="download-invoice-btn" onclick="invoiceApp.downloadInvoice('${data.pdf_path}')">
                        <i class="fas fa-download"></i> Download PDF Invoice
                    </a>`;
                    
                    this.addMessage(`✅ Invoice generated successfully!<br>Invoice #: ${data.invoice_number}<br>Total: ₹${data.invoice.summary.grand_total.toFixed(2)}<br><br>${downloadBtn}`, 'ai');
                    this.updateCartCount(0);
                } else {
                    this.addMessage(`❌ ${data.error || 'Error generating invoice'}`, 'ai', true);
                }
            }
        } catch (error) {
            console.error('Invoice generation error:', error);
            this.addMessage(`❌ Error generating invoice: ${error.message}`, 'ai', true);
        }
    }

    async downloadInvoice(filename) {
        
            const response = await fetch(`${this.API_BASE_URL}/download_invoice/${filename}`);
            if (response.ok) {
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = filename;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
            }
        
    }

    async downloadCurrentChat() {
        // Implementation for downloading current chat as PDF
        this.addMessage('📄 Generating chat PDF...', 'ai');
        // Add your PDF generation logic here
    }

    async loadClientDetails() {
        try {
            const response = await fetch(`${this.API_BASE_URL}/client/get`, {
                headers: { 'Session-ID': this.sessionId }
            });
            
            if (response.ok) {
                const data = await response.json();
                if (data.client) {
                    const fields = ['clientName', 'clientEmail', 'clientPhone', 'clientAddress', 'clientGST', 'clientPlace'];
                    const clientData = ['name', 'email', 'phone', 'address', 'gst_number', 'place_of_supply'];
                    
                    fields.forEach((field, index) => {
                        if (this.elements[field] && data.client[clientData[index]]) {
                            this.elements[field].value = data.client[clientData[index]];
                        }
                    });
                }
            }
        } catch (error) {
            console.error('Error loading client details:', error);
        }
    }

    async saveClientDetails() {
        const clientData = {
            name: this.elements.clientName?.value || '',
            email: this.elements.clientEmail?.value || '',
            phone: this.elements.clientPhone?.value || '',
            address: this.elements.clientAddress?.value || '',
            gst_number: this.elements.clientGST?.value || '',
            place_of_supply: this.elements.clientPlace?.value || '',
            session_id: this.sessionId
        };

        try {
            const response = await fetch(`${this.API_BASE_URL}/client/save`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Session-ID': this.sessionId
                },
                body: JSON.stringify(clientData)
            });

            if (response.ok) {
                this.addMessage('✅ Client details saved successfully', 'ai');
                this.closeClientModal();
            } else {
               this.addMessage('❌ Error saving client details', 'ai', true);
           }
       } catch (error) {
           console.error('Save client error:', error);
           this.addMessage('❌ Error saving client details', 'ai', true);
       }
   }

   updateChatList() {
       // Implementation for updating chat history in sidebar
       // This would typically involve updating the chat list UI
       if (this.elements.chatList) {
           // Add current chat to history
           const chatItem = document.createElement('div');
           chatItem.className = 'chat-item active';
           chatItem.innerHTML = `
               <i class="fas fa-message"></i>
               <span>New Chat - ${new Date().toLocaleDateString()}</span>
               <button class="chat-delete" onclick="invoiceApp.deleteChat('${this.currentChatId}')">
                   <i class="fas fa-trash"></i>
               </button>
           `;
           
           // Remove active class from other chats
           this.elements.chatList.querySelectorAll('.chat-item').forEach(item => {
               item.classList.remove('active');
           });
           
           this.elements.chatList.insertBefore(chatItem, this.elements.chatList.firstChild);
       }
   }

   deleteChat(chatId) {
       // Implementation for deleting a chat
       console.log('Deleting chat:', chatId);
   }

   showCartSummary() {
       // Send a message to show cart details
       if (this.elements.messageInput) {
           this.elements.messageInput.value = 'show cart breakdown';
           this.sendMessage();
       }
       this.closeSidebar();
   }

   handleKeyboardShortcuts(e) {
       // Escape key closes modals
       if (e.key === 'Escape') {
           this.closeAllModals();
           this.closeSidebar();
       }

       // Ctrl/Cmd + K for new chat
       if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
           e.preventDefault();
           this.startNewChat();
       }

       // Ctrl/Cmd + U for upload
       if ((e.ctrlKey || e.metaKey) && e.key === 'u') {
           e.preventDefault();
           this.openUploadModal();
       }

       // Ctrl/Cmd + D for download
       if ((e.ctrlKey || e.metaKey) && e.key === 'd') {
           e.preventDefault();
           this.downloadCurrentChat();
       }
   }

   handleResize() {
       // Close sidebar on desktop resize
       if (window.innerWidth > 768) {
           this.closeSidebar();
       }
   }

   closeAllModals() {
       this.closeUploadModal();
       this.closeClientModal();
   }

   // Quick action functions that can be called from HTML
   sendQuickMessage(message) {
       if (this.elements.messageInput) {
           this.elements.messageInput.value = message;
           this.sendMessage();
       }
   }

   // Modal control functions
   openUploadModal() {
       if (this.elements.uploadModal) {
           this.elements.uploadModal.classList.add('active');
       }
   }

   closeUploadModal() {
       if (this.elements.uploadModal) {
           this.elements.uploadModal.classList.remove('active');
       }
       // Reset upload area
       if (this.elements.uploadProgress) {
           this.elements.uploadProgress.style.display = 'none';
       }
       if (this.elements.fileInput) {
           this.elements.fileInput.value = '';
       }
   }

   openClientModal() {
       if (this.elements.clientModal) {
           this.elements.clientModal.classList.add('active');
       }
   }

   closeClientModal() {
       if (this.elements.clientModal) {
           this.elements.clientModal.classList.remove('active');
       }
   }

   // Utility functions
   formatCurrency(amount) {
       return new Intl.NumberFormat('en-IN', {
           style: 'currency',
           currency: 'INR'
       }).format(amount);
   }

   showNotification(message, type = 'info') {
       // Implementation for showing toast notifications
       console.log(`${type.toUpperCase()}: ${message}`);
   }

   // Auto-save functionality
   autoSaveChat() {
       // Implementation for auto-saving chat state
       if (this.currentChatId && this.elements.chatMessages) {
           const chatData = {
               id: this.currentChatId,
               messages: this.elements.chatMessages.innerHTML,
               timestamp: Date.now()
           };
           
           // Save to localStorage or send to server
           localStorage.setItem(`chat_${this.currentChatId}`, JSON.stringify(chatData));
       }
   }

   // Connection monitoring
   startConnectionMonitoring() {
       setInterval(() => {
           this.checkConnection();
       }, 30000); // Check every 30 seconds
   }

   // Voice input functionality (future enhancement)
   initVoiceInput() {
       if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
           // Implementation for voice input
           console.log('Voice recognition available');
       }
   }

   // Export chat functionality
   exportChat(format = 'json') {
       if (!this.elements.chatMessages) return;

       const messages = Array.from(this.elements.chatMessages.querySelectorAll('.message')).map(msg => {
           const isUser = msg.classList.contains('user-message');
           const content = msg.querySelector('.message-text').textContent.trim();
           return {
               type: isUser ? 'user' : 'assistant',
               content: content,
               timestamp: new Date().toISOString()
           };
       });

       const chatExport = {
           sessionId: this.sessionId,
           messages: messages,
           exportDate: new Date().toISOString()
       };

       const blob = new Blob([JSON.stringify(chatExport, null, 2)], { 
           type: 'application/json' 
       });
       
       const url = URL.createObjectURL(blob);
       const a = document.createElement('a');
       a.href = url;
       a.download = `chat-export-${this.sessionId}.json`;
       document.body.appendChild(a);
       a.click();
       document.body.removeChild(a);
       URL.revokeObjectURL(url);
   }
}

// Global functions for HTML onclick handlers
function openUploadModal() {
   window.invoiceApp.openUploadModal();
}

function closeUploadModal() {
   window.invoiceApp.closeUploadModal();
}

function openClientModal() {
   window.invoiceApp.openClientModal();
}

function closeClientModal() {
   window.invoiceApp.closeClientModal();
}

function saveClientDetails() {
   window.invoiceApp.saveClientDetails();
}

function toggleTheme() {
   window.invoiceApp.toggleTheme();
}

function downloadCurrentChat() {
   window.invoiceApp.downloadCurrentChat();
}

function showCartSummary() {
   window.invoiceApp.showCartSummary();
}

function closeSidebar() {
   window.invoiceApp.closeSidebar();
}

// Initialize the application
window.invoiceApp = new InvoiceAssistant();

// Start connection monitoring
window.invoiceApp.startConnectionMonitoring();

// Auto-save chat every 30 seconds
setInterval(() => {
   window.invoiceApp.autoSaveChat();
}, 30000);

// Service Worker registration for PWA capabilities (optional)
if ('serviceWorker' in navigator) {
   window.addEventListener('load', () => {
       navigator.serviceWorker.register('/sw.js')
           .then(registration => {
               console.log('SW registered: ', registration);
           })
           .catch(registrationError => {
               console.log('SW registration failed: ', registrationError);
           });
   });
}

console.log('🎉 AI Invoice Assistant loaded successfully!');
console.log('💡 Keyboard shortcuts:');
console.log('  • Ctrl/Cmd + K: New chat');
console.log('  • Ctrl/Cmd + U: Upload catalog');
console.log('  • Ctrl/Cmd + D: Download chat');
console.log('  • Escape: Close modals/sidebar');